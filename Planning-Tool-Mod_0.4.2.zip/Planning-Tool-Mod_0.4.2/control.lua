    require "defines"
    require "util"

    script.on_init(function()
       initTables()
    end)


    script.on_load(function()
       initTables()
       if global.planningTool.visible == true then
          showGUI()
       end
    end)

    script.on_event(defines.events.on_put_item, function(event)
        if pcall(function ()
            local t = game.player.cursor_stack.name
        end) then
           if game.player.cursor_stack.name == "planning-tool" then
          
              if game.player.gui.left.planningTool == nil then
                 showGUI()
                 return
              else
                 if global.planningTool.hideFlag == true then
                    game.player.print({"drawingNotPossible"})
                    return
                 end

                 if global.planningTool.modeFlag == false then
                    drawFreehand(event)
                 else
                    if global.planningTool.armed == false then
                  showSelect()
                       global.planningTool.startPos = event.position
                       global.planningTool.armed = true
                    else
                       global.planningTool.endPos = event.position
                       drawPreview()
                    end
                 end
             end
          end
       end
    end)

    function applyselection()
      for _, preObj in ipairs(global.planningTool.previewObjects) do
        local tmpPos = preObj.position
        local color = global.planningTool.color
        local EntName = "pt-overlay-"..color
        if global.planningTool.checkerboardFlag then
          EntName = EntName ..((math.floor(tmpPos.x) + math.floor(tmpPos.y)) % 2)
        else
          EntName = EntName .."0"
        end

        local tmpValid = true
        for index, obj in ipairs(global.planningTool.objects) do
          if obj.valid == true then
            if (obj.position.x == tmpPos.x) and (obj.position.y == tmpPos.y) then
              if (global.planningTool.overwriteFlag == true) or (global.planningTool.color == "remove") then
                obj.destroy()
                table.remove(global.planningTool.objects, index)
                if global.planningTool.color ~= "remove" then
                  table.insert(global.planningTool.objects, game.get_surface(1).create_entity{name = EntName, position = tmpPos})
                end
                tmpValid = false
                break
              else
                tmpValid = false
                break
              end
            end
          end
        end
        if (tmpValid == true) and (global.planningTool.color ~= "remove") then
          table.insert(global.planningTool.objects, game.get_surface(1).create_entity{name = EntName, position = tmpPos})
        end
      end
    end

    function clearPreview ()
      while (#global.planningTool.previewObjects > 0) do
        if global.planningTool.previewObjects[#global.planningTool.previewObjects].valid == true then
          global.planningTool.previewObjects[#global.planningTool.previewObjects].destroy()
        end
        table.remove(global.planningTool.previewObjects)
      end
      global.planningTool.armed = false
      global.planningTool.size = {x = 0, y = 0}
      game.player.gui.left.planningTool.destroy()
      showGUI()
    end

    script.on_event(defines.events.on_gui_click, function(event)
       if event.element.name == "ptColorButton" then
          global.planningTool.colorIndex = global.planningTool.colorIndex + 1
          if global.planningTool.colorIndex > 7 then
             global.planningTool.colorIndex = 1
          end
          global.planningTool.color = global.planningTool.colors[global.planningTool.colorIndex]
          game.player.gui.left.planningTool.destroy()
          showGUI()
       elseif event.element.name =="ptHideButton" then
          if global.planningTool.hideFlag == false then
             global.planningTool.hideFlag = true
             hideObjects(true)
          else
             global.planningTool.hideFlag = false
             hideObjects(false)
          end
          game.player.gui.left.planningTool.destroy()
          showGUI()
       elseif event.element.name =="ptRemoveAllButton" then
          removeAll()
       elseif event.element.name == "ptCloseButton" then
          global.planningTool.visible = false
          game.player.gui.left.planningTool.destroy()
          return
       elseif event.element.name == "ptModeCheck" then
          if global.planningTool.modeFlag == false then
             global.planningTool.modeFlag = true
          else
             global.planningTool.modeFlag = false
          end
          game.player.gui.left.planningTool.destroy()
          showGUI()
       elseif event.element.name == "ptFilledCheck" then
          if global.planningTool.filledFlag == false then
             global.planningTool.filledFlag = true
          else
             global.planningTool.filledFlag = false
          end
          game.player.gui.left.planningTool.destroy()
          showGUI()
       elseif event.element.name == "ptOverwriteCheck" then
          if global.planningTool.overwriteFlag == false then
             global.planningTool.overwriteFlag = true
          else
             global.planningTool.overwriteFlag = false
          end
          game.player.gui.left.planningTool.destroy()
          showGUI()
       elseif event.element.name == "ptCheckerboardCheck" then
          if global.planningTool.checkerboardFlag == false then
             global.planningTool.checkerboardFlag = true
          else
             global.planningTool.checkerboardFlag = false
          end
          game.player.gui.left.planningTool.destroy()
          showGUI()
       elseif event.element.name == "stFinish" then
        applyselection()
        clearPreview()
        global.selectTool.visible = false
        game.player.gui.top.selectTool.destroy()
       elseif event.element.name == "stCancel" then
        clearPreview()
        global.selectTool.visible = false
        game.player.gui.top.selectTool.destroy()
       end
    end)



    function initTables()


       if global.planningTool == nil then
          global.planningTool = {}
       end
       
       if global.selectTool == nil then
          global.selectTool = {}
       end

       if global.planningTool.colors == nil then
          global.planningTool.colors = {"blue", "cyan", "green", "magenta", "red", "yellow", "remove"}
       end

       if global.planningTool.colorIndex == nil then
          global.planningTool.colorIndex = 1
       end

       if global.planningTool.color == nil then
          global.planningTool.color = global.planningTool.colors[global.planningTool.colorIndex]
       end

       if global.planningTool.objects == nil then
          global.planningTool.objects = {}
       end

       if global.planningTool.hiddenObjects == nil then
          global.planningTool.hiddenObjects = {}
       end

      if global.selectTool.visible == nil then
        global.selectTool.visible = false
      end
     
       if global.planningTool.visible == nil then
          global.planningTool.visible = false
       end

       if global.planningTool.overwriteFlag == nil then
          global.planningTool.overwriteFlag = false
       end

       if global.planningTool.checkerboardFlag == nil then
          global.planningTool.checkerboardFlag = false
       end

       if global.planningTool.modeFlag == nil then
          global.planningTool.modeFlag = false --"freehand" == false; "rect" == true
       end

       if global.planningTool.filledFlag == nil then
          global.planningTool.filledFlag = false
       end

       if global.planningTool.armed == nil then
          global.planningTool.armed = false
       end

       if global.planningTool.startPos == nil then
          global.planningTool.startPos = {}
       end
       
       if global.planningTool.endPos == nil then
          global.planningTool.endPos = {}
       end

       if global.planningTool.previewObjects == nil then
          global.planningTool.previewObjects = {}
       end

       if global.planningTool.hideFlag == nil then
          global.planningTool.hideFlag = false
       end

       if global.planningTool.size == nil then
          global.planningTool.size = {x = 0, y = 0}
       end
    end

    function showSelect()
      if game.player.gui.top.selectTool == nil then
        global.selectTool.visible=true
        local rootFrame = game.player.gui.top.add{type="frame", name="selectTool", caption="Selection Tool", direction = "vertical"}
        local table = rootFrame.add{type="table", name = "selectToolTable", colspan = 2}
        table.add{type = "button", name = "stFinish", caption="Finish"}
        table.add{type = "button", name = "stCancel", caption="Cancel"}
      end
    end

    function showGUI()
       if game.player.gui.left.planningTool == nil then
          global.planningTool.visible = true
          local rootFrame = game.player.gui.left.add{type = "frame", name = "planningTool", caption = {"planningTool"}, direction = "vertical"}
          local table = rootFrame.add{type ="table", name = "planningToolTable", colspan = 2}
             table.add{type = "label", name = "ptColorLabel", caption = {"colorLabel"}}
             table.add{type = "button", name = "ptColorButton", caption = getColorName(), style = "smallerButtonFont"}
             table.add{type = "label", name = "ptModeLabel", caption = {"modeLabel"}}
             table.add{type = "checkbox", name = "ptModeCheck", state = global.planningTool.modeFlag}
             if global.planningTool.modeFlag == true then
                table.add{type = "label", name = "ptFilledLabel", caption = {"filledLabel"}}
                table.add{type = "checkbox", name = "ptFilledCheck", state = global.planningTool.filledFlag}
             end
             table.add{type = "label", name = "ptOverwriteLabel", caption = {"overwriteLabel"}}
             table.add{type = "checkbox", name = "ptOverwriteCheck", state = global.planningTool.overwriteFlag}
             table.add{type = "label", name = "ptCheckerboardLabel", caption = {"checkerboardLabel"}}
             table.add{type = "checkbox", name = "ptCheckerboardCheck", state = global.planningTool.checkerboardFlag}
          if global.planningTool.modeFlag == true then
             local size = global.planningTool.size
             if (size.x ~= 0) and (size.y ~= 0) then
                table.add{type = "label", name = "ptSizeLabel", caption = {"sizeLabel"}}
                table.add{type = "label", name = "ptSizeLabel2", caption = size.x.."x"..size.y}
             end
          end
          local hideCaption
          if global.planningTool.hideFlag == false then
             hideCaption = {"hideHideButton"}
          else
             hideCaption = {"hideShowButton"}
          end
          rootFrame.add{type ="button", name = "ptHideButton", caption = hideCaption, style = "smallerButtonFont"}
          rootFrame.add{type ="button", name = "ptRemoveAllButton", caption = {"removeAllButton"}, style = "smallerButtonFont"}
          rootFrame.add{type ="button", name = "ptCloseButton", caption = {"closeButton"}, style = "smallerButtonFont"}
       end
    end

    function getColorName()
       for _, color in ipairs(global.planningTool.colors) do
          if global.planningTool.color == color then
             return {color}
          end
       end
    end

    function removeAll()
       while #global.planningTool.objects > 0 do
          if global.planningTool.objects[#global.planningTool.objects].valid then
             global.planningTool.objects[#global.planningTool.objects].destroy()
          end
          table.remove(global.planningTool.objects)
       end
    end






    function drawFreehand(event)
       local color = global.planningTool.color
       local EntName = "pt-overlay-"..color
       
       if global.planningTool.checkerboardFlag then
          EntName = EntName ..((math.floor(event.position.x) + math.floor(event.position.y)) % 2)
       else
          EntName = EntName .."0"
       end
             
       if global.planningTool.colorIndex ~= 7 then
          if (game.get_surface(1).can_place_entity{name = EntName, position = event.position}) then
          -- entityBuilt = game.player.build_from_cursor({name = EntName, position = event.position})
          -- if (entityBuilt) then
             table.insert(global.planningTool.objects, game.get_surface(1).create_entity{name = EntName, position = event.position})
             -- table.insert(global.planningTool.objects, entityBuilt)
          elseif global.planningTool.overwriteFlag == true then
             local PosB = {x = math.floor(event.position.x), y = math.floor(event.position.y)}
             local PosE = {x = math.ceil(event.position.x), y = math.ceil(event.position.y)}
             local obstacles = game.get_surface(1).find_entities_filtered{area = {PosB, PosE}, type="decorative"}
             for _, object in ipairs(obstacles) do
                local tmp1, tmp2 = string.find(object.name, "pt-overlay", 1, true)
                if (tmp1 ~= nil) and (tmp2 ~= nil) then
                   if object.valid == true then
                      object.destroy()
                   end
                end
             end
             table.insert(global.planningTool.objects, game.get_surface(1).create_entity{name = EntName, position = event.position})
          end
       else -- color == "remove"
          if not game.get_surface(1).can_place_entity{name = EntName, position = event.position} then
             local PosB = {x = math.floor(event.position.x), y = math.floor(event.position.y)}
             local PosE = {x = math.ceil(event.position.x), y = math.ceil(event.position.y)}
             local obstacles = game.get_surface(1).find_entities_filtered{area = {PosB, PosE}, type="decorative"}
             for _, object in ipairs(obstacles) do
                local tmp1, tmp2 = string.find(object.name, "pt-overlay", 1, true)
                if (tmp1 ~= nil) and (tmp2 ~= nil) then
                   if object.valid == true then
                      object.destroy()
                   end
                end
             end
          end
       end
    end


    function drawPreview()
       while (#global.planningTool.previewObjects > 0) do
          if global.planningTool.previewObjects[#global.planningTool.previewObjects].valid == true then
             global.planningTool.previewObjects[#global.planningTool.previewObjects].destroy()
          end
          table.remove(global.planningTool.previewObjects)
       end

       local color = global.planningTool.color
       local EntName = "pt-overlay-"..color.."1"
       
       local cursorPos = global.planningTool.endPos
       cursorPos.x = math.floor(cursorPos.x)
       cursorPos.y = math.floor(cursorPos.y)

       local startPos = global.planningTool.startPos
       startPos.x = math.floor(startPos.x)
       startPos.y = math.floor(startPos.y)

       global.planningTool.size.x = math.abs(startPos.x - cursorPos.x) + 1
       global.planningTool.size.y = math.abs(startPos.y - cursorPos.y) + 1
       if game.player.gui.left.planningTool ~= nil then game.player.gui.left.planningTool.destroy() end
       showGUI()

       local stepX, stepY
       if startPos.x >= cursorPos.x then
          stepX = -1
       else
          stepX = 1
       end
       if startPos.y >= cursorPos.y then
          stepY = -1
       else
          stepY = 1
       end

       if global.planningTool.filledFlag == true then
          for i = startPos.x, cursorPos.x, stepX do
             for j = startPos.y, cursorPos.y, stepY do
                table.insert(global.planningTool.previewObjects, game.get_surface(1).create_entity{name = EntName, position = {x = i, y = j}})
             end
          end
       else
          for i = startPos.x, cursorPos.x, stepX do
             table.insert(global.planningTool.previewObjects, game.get_surface(1).create_entity{name = EntName, position = {x = i, y = cursorPos.y}})
             table.insert(global.planningTool.previewObjects, game.get_surface(1).create_entity{name = EntName, position = {x = i, y = startPos.y}})
          end

          for j = startPos.y + stepY, cursorPos.y - stepY, stepY do
             table.insert(global.planningTool.previewObjects, game.get_surface(1).create_entity{name = EntName, position = {x = startPos.x, y = j}})
             table.insert(global.planningTool.previewObjects, game.get_surface(1).create_entity{name = EntName, position = {x = cursorPos.x, y = j}})
          end
       end
    end

    function hideObjects(shouldHide)
       if shouldHide == true then
          while (#global.planningTool.objects > 0) do
             local tmpObj = global.planningTool.objects[#global.planningTool.objects]
             table.insert(global.planningTool.hiddenObjects, {name = tmpObj.name, position = tmpObj.position})
             if global.planningTool.objects[#global.planningTool.objects].valid == true then
                global.planningTool.objects[#global.planningTool.objects].destroy()
             end
             table.remove(global.planningTool.objects)
          end
       else
          while (#global.planningTool.hiddenObjects > 0) do
             local tmpObj = global.planningTool.hiddenObjects[#global.planningTool.hiddenObjects]
             table.insert(global.planningTool.objects, game.get_surface(1).create_entity{name = tmpObj.name, position = tmpObj.position})
             table.remove(global.planningTool.hiddenObjects)
          end
       end
    end

    function tblLength(t)
        local count = 0
        for k,v in pairs(t) do
            count = count + 1
        end
        return count
    end
