data:extend(
{
	{
		type = "item",
		name = "planning-tool",
		icon = "__Planning-Tool-Mod__/graphics/planning-tool.png",
		flags = {"goes-to-quickbar"},
		damage_radius = 5,
		subgroup = "tool",
		order = "b[planning-tool]",
		place_result = "planning-tool",
		stack_size = 1
	},

	{
		type = "decorative",
		name = "planning-tool",
		flags = {"placeable-neutral", "not-on-map"},
		icon = "__Planning-Tool-Mod__/graphics/planning-tool.png",
		collision_mask = {"ground-tile", "water-tile"},
		subgroup = "grass",
		order = "b[decorative]-b[planning-tool]",
		collision_box = {{-0.4, -0.4}, {0.4, 0.4}},
		selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
		selectable_in_game = false,
		render_layer = "radius-visualization",
		pictures =
		{
			{
				filename = "__Planning-Tool-Mod__/graphics/planning-tool.png",
				width = 32,
				height = 32
			}
		}
	},

	{
		type = "recipe",
		name = "planning-tool",
		ingredients = {{"electronic-circuit",10},{"copper-cable",20}},
		result = "planning-tool",
		result_count = 1,
		enabled = "false"
	},

	{
		type = "technology",
		name = "planning-tool",
		icon = "__Planning-Tool-Mod__/graphics/planning-tool.png",
		effects = {
			{
				type = "unlock-recipe",
				recipe = "planning-tool"
			}
		},
		prerequisites = {
			"optics"
		},
		unit = {
			count = 50,
			ingredients = {
				{"science-pack-1", 2},
				{"science-pack-2", 1}
			},
			time = 10
		}
	},






	{
		type = "decorative",
		name = "pt-overlay-blue0",
		flags = {"placeable-neutral", "not-on-map"},
		icon = "__Planning-Tool-Mod__/graphics/pt-overlay-blue0.png",
		collision_mask = { "ghost-layer"},
		subgroup = "grass",
		order = "b[decorative]-b[pt-overlay-blue]",
		collision_box = {{-0.4, -0.4}, {0.4, 0.4}},
		selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
		selectable_in_game = false,
		render_layer = "radius-visualization",
		pictures =
		{
			{
				filename = "__Planning-Tool-Mod__/graphics/pt-overlay-blue0.png",
				width = 32,
				height = 32
			}
		}
	},
	{
		type = "decorative",
		name = "pt-overlay-blue1",
		flags = {"placeable-neutral", "not-on-map"},
		icon = "__Planning-Tool-Mod__/graphics/pt-overlay-blue0.png",
		collision_mask = { "ghost-layer"},
		subgroup = "grass",
		order = "b[decorative]-b[pt-overlay-blue]",
		collision_box = {{-0.4, -0.4}, {0.4, 0.4}},
		selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
		selectable_in_game = false,
		render_layer = "radius-visualization",
		pictures =
		{
			{
				filename = "__Planning-Tool-Mod__/graphics/pt-overlay-blue1.png",
				width = 32,
				height = 32
			}
		}
	},

	{
		type = "decorative",
		name = "pt-overlay-cyan0",
		flags = {"placeable-neutral", "not-on-map"},
		icon = "__Planning-Tool-Mod__/graphics/pt-overlay-cyan0.png",
		collision_mask = { "ghost-layer"},
		subgroup = "grass",
		order = "b[decorative]-b[pt-overlay-cyan]",
		collision_box = {{-0.4, -0.4}, {0.4, 0.4}},
		selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
		selectable_in_game = false,
		render_layer = "radius-visualization",
		pictures =
		{
			{
				filename = "__Planning-Tool-Mod__/graphics/pt-overlay-cyan0.png",
				width = 32,
				height = 32
			}
		}
	},
	{
		type = "decorative",
		name = "pt-overlay-cyan1",
		flags = {"placeable-neutral", "not-on-map"},
		icon = "__Planning-Tool-Mod__/graphics/pt-overlay-cyan0.png",
		collision_mask = { "ghost-layer"},
		subgroup = "grass",
		order = "b[decorative]-b[pt-overlay-cyan]",
		collision_box = {{-0.4, -0.4}, {0.4, 0.4}},
		selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
		selectable_in_game = false,
		render_layer = "radius-visualization",
		pictures =
		{
			{
				filename = "__Planning-Tool-Mod__/graphics/pt-overlay-cyan1.png",
				width = 32,
				height = 32
			}
		}
	},
		
	{
		type = "decorative",
		name = "pt-overlay-green0",
		flags = {"placeable-neutral", "not-on-map"},
		icon = "__Planning-Tool-Mod__/graphics/pt-overlay-green0.png",
		collision_mask = { "ghost-layer"},
		subgroup = "grass",
		order = "b[decorative]-b[pt-overlay-green]",
		collision_box = {{-0.4, -0.4}, {0.4, 0.4}},
		selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
		selectable_in_game = false,
		render_layer = "radius-visualization",
		pictures =
		{
			{
				filename = "__Planning-Tool-Mod__/graphics/pt-overlay-green0.png",
				width = 32,
				height = 32
			}
		}
	},
	{
		type = "decorative",
		name = "pt-overlay-green1",
		flags = {"placeable-neutral", "not-on-map"},
		icon = "__Planning-Tool-Mod__/graphics/pt-overlay-green0.png",
		collision_mask = { "ghost-layer"},
		subgroup = "grass",
		order = "b[decorative]-b[pt-overlay-green]",
		collision_box = {{-0.4, -0.4}, {0.4, 0.4}},
		selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
		selectable_in_game = false,
		render_layer = "radius-visualization",
		pictures =
		{
			{
				filename = "__Planning-Tool-Mod__/graphics/pt-overlay-green1.png",
				width = 32,
				height = 32
			}
		}
	},

	{
		type = "decorative",
		name = "pt-overlay-magenta0",
		flags = {"placeable-neutral", "not-on-map"},
		icon = "__Planning-Tool-Mod__/graphics/pt-overlay-magenta0.png",
		collision_mask = { "ghost-layer"},
		subgroup = "grass",
		order = "b[decorative]-b[pt-overlay-magenta]",
		collision_box = {{-0.4, -0.4}, {0.4, 0.4}},
		selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
		selectable_in_game = false,
		render_layer = "radius-visualization",
		pictures =
		{
			{
				filename = "__Planning-Tool-Mod__/graphics/pt-overlay-magenta0.png",
				width = 32,
				height = 32
			}
		}
	},
	{
		type = "decorative",
		name = "pt-overlay-magenta1",
		flags = {"placeable-neutral", "not-on-map"},
		icon = "__Planning-Tool-Mod__/graphics/pt-overlay-magenta0.png",
		collision_mask = { "ghost-layer"},
		subgroup = "grass",
		order = "b[decorative]-b[pt-overlay-magenta]",
		collision_box = {{-0.4, -0.4}, {0.4, 0.4}},
		selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
		selectable_in_game = false,
		render_layer = "radius-visualization",
		pictures =
		{
			{
				filename = "__Planning-Tool-Mod__/graphics/pt-overlay-magenta1.png",
				width = 32,
				height = 32
			}
		}
	},
	
	{
		type = "decorative",
		name = "pt-overlay-red0",
		flags = {"placeable-neutral", "not-on-map"},
		icon = "__Planning-Tool-Mod__/graphics/pt-overlay-red0.png",
		collision_mask = { "ghost-layer"},
		subgroup = "grass",
		order = "b[decorative]-b[pt-overlay-red]",
		collision_box = {{-0.4, -0.4}, {0.4, 0.4}},
		selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
		selectable_in_game = false,
		render_layer = "radius-visualization",
		pictures =
		{
			{
				filename = "__Planning-Tool-Mod__/graphics/pt-overlay-red0.png",
				width = 32,
				height = 32
			}
		}
	},
	{
		type = "decorative",
		name = "pt-overlay-red1",
		flags = {"placeable-neutral", "not-on-map"},
		icon = "__Planning-Tool-Mod__/graphics/pt-overlay-red0.png",
		collision_mask = { "ghost-layer"},
		subgroup = "grass",
		order = "b[decorative]-b[pt-overlay-red]",
		collision_box = {{-0.4, -0.4}, {0.4, 0.4}},
		selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
		selectable_in_game = false,
		render_layer = "radius-visualization",
		pictures =
		{
			{
				filename = "__Planning-Tool-Mod__/graphics/pt-overlay-red1.png",
				width = 32,
				height = 32
			}
		}
	},
	
	{
		type = "decorative",
		name = "pt-overlay-yellow0",
		flags = {"placeable-neutral", "not-on-map"},
		icon = "__Planning-Tool-Mod__/graphics/pt-overlay-yellow0.png",
		collision_mask = { "ghost-layer"},
		subgroup = "grass",
		order = "b[decorative]-b[pt-overlay-yellow]",
		collision_box = {{-0.4, -0.4}, {0.4, 0.4}},
		selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
		selectable_in_game = false,
		render_layer = "radius-visualization",
		pictures =
		{
			{
				filename = "__Planning-Tool-Mod__/graphics/pt-overlay-yellow0.png",
				width = 32,
				height = 32
			}
		}
	},
	{
		type = "decorative",
		name = "pt-overlay-yellow1",
		flags = {"placeable-neutral", "not-on-map"},
		icon = "__Planning-Tool-Mod__/graphics/pt-overlay-yellow0.png",
		collision_mask = { "ghost-layer"},
		subgroup = "grass",
		order = "b[decorative]-b[pt-overlay-yellow]",
		collision_box = {{-0.4, -0.4}, {0.4, 0.4}},
		selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
		selectable_in_game = false,
		render_layer = "radius-visualization",
		pictures =
		{
			{
				filename = "__Planning-Tool-Mod__/graphics/pt-overlay-yellow1.png",
				width = 32,
				height = 32
			}
		}
	},
	
	{
		type = "decorative",
		name = "pt-overlay-remove0",
		flags = {"placeable-neutral", "not-on-map"},
		icon = "__Planning-Tool-Mod__/graphics/pt-overlay-remove0.png",
		collision_mask = { "ghost-layer"},
		subgroup = "grass",
		order = "b[decorative]-b[pt-overlay-remove]",
		collision_box = {{-0.4, -0.4}, {0.4, 0.4}},
		selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
		selectable_in_game = false,
		render_layer = "radius-visualization",
		pictures =
		{
			{
				filename = "__Planning-Tool-Mod__/graphics/pt-overlay-remove0.png",
				width = 32,
				height = 32
			}
		}
	},
	{
		type = "decorative",
		name = "pt-overlay-remove1",
		flags = {"placeable-neutral", "not-on-map"},
		icon = "__Planning-Tool-Mod__/graphics/pt-overlay-remove0.png",
		collision_mask = { "ghost-layer"},
		subgroup = "grass",
		order = "b[decorative]-b[pt-overlay-remove]",
		collision_box = {{-0.4, -0.4}, {0.4, 0.4}},
		selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
		selectable_in_game = false,
		render_layer = "radius-visualization",
		pictures =
		{
			{
				filename = "__Planning-Tool-Mod__/graphics/pt-overlay-remove1.png",
				width = 32,
				height = 32
			}
		}
	}
  
}
)



local smallerButtonFont =
{
	type = "button_style",
	parent = "button_style",
	font = "default"
}
data.raw["gui-style"].default["smallerButtonFont"] = smallerButtonFont