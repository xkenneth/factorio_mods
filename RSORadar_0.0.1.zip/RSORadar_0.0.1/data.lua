require("prototypes.entity.RSORadar")
