data:extend({
 {
    type = "recipe",
    name = "gunship",
    enabled = "false",
    ingredients = 
    {
      {"electric-engine-unit",32},
      {"steel-plate",100},
      {"iron-plate",200},
      {"advanced-circuit",20},
			{"submachine-gun",1},
			{"rocket-launcher",1},
			
    },
    result = "gunship"
  }
})