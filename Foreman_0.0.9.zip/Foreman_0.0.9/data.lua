-- --entity
require("prototypes.style")

-- --items
-- require("prototypes.item.items")

-- --recipies
-- require("prototypes.recipe.recipes")