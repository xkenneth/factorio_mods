config = {}

-- change to false to disable overwriting if no empty blueprint is found
config.overwrite = true

-- change to false to not require an electronic circuit when overwriting
config.useCircuit = true